package valoraciones;

/**
 * Enumerado que representa la valoracion de una recomendacion
 * 
 * @author Álvaro Mendez y Alejandro Monterrubio // alvaro.mendezl@estudiante.uam.es alejandro.monterrubio@estudiante.uam.es
 */
public enum Valoracion {
    LIKE, DISLIKE;
}