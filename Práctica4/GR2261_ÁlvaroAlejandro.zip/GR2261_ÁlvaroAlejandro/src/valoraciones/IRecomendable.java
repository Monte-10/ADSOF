package valoraciones;

public interface IRecomendable {
    String getDescripcion();
}