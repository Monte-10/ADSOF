package valoraciones;

public interface IUsuario {
    String getId();
}