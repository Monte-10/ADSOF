package excepciones;

public class ExcepcionFonoteca extends Exception{
    public ExcepcionFonoteca(String mensaje) {
        super(mensaje);
    }
}
