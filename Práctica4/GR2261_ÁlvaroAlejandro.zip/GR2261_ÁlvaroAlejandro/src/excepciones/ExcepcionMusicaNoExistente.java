package excepciones;

public class ExcepcionMusicaNoExistente extends ExcepcionFonoteca{
    public ExcepcionMusicaNoExistente(String mensaje) {
        super(mensaje);
    }
}
