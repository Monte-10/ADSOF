package excepciones;

public class ExcepcionCancionRepetida extends ExcepcionFonoteca {
    public ExcepcionCancionRepetida(String mensaje) {
        super(mensaje);
    }
}
